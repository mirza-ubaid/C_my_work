
local os = require "os"
local io = require "io"
local nixio = require "nixio"
local string = require "string"
local math = require "math"
local fs = require "luci.fs"
local util = require "luci.util"

local ipairs, pairs, next, loadstring, tonumber, tostring = ipairs, pairs, next, loadstring, tonumber, tostring

module "luci.erutil"

writefile = nixio.fs.writefile

execute = os.execute

exec = util.exec

function execw(command)
        local pp   = io.popen(command)
        local data = pp:read("*l") or ""
        pp:close()
        return data:match("%S+") or ""
end

function execl(command)
        local pp   = io.popen(command)
        local data = pp:read("*l") or ""
        pp:close()
        return data:match("[^\n]+") or ""
end

function get_dsl_stats(last)
	local dsl_stat = ""
	if last == "last" then
		dsl_stat = exec("cat /root/dsl_control_lucistat")
	end
	if dsl_stat == "" then
		dsl_stat = exec("/etc/init.d/dsl_control lucistat") or ""
		if dsl_stat == "" then return end
	 	if last == "sqm" then
                	writefile("/root/dsl_control_lucistat", dsl_stat)
		end
        end

	local dsl_func = loadstring(dsl_stat)
        local dsl = dsl_func()

        local function conv_data_rate(data_rate)
        	local iter = string.gmatch(data_rate, "[^ ]+")
        	local val = tonumber(iter())
        	local unit = iter()
        	if unit == "Mb" then
        		val = val * 1000;
        	end
        	return string.gmatch(tostring(val), "[^.]+")()
        end

        dsl.data_rate_down_s = conv_data_rate(dsl.data_rate_down_s);
        dsl.data_rate_up_s = conv_data_rate(dsl.data_rate_up_s);

        if dsl.noise_margin_down > 20 and dsl.noise_margin_up > 20 then
        	dsl.noise_margin_rate = "A"
        elseif dsl.noise_margin_down >= 11 and dsl.noise_margin_up >= 11 then
        	dsl.noise_margin_rate = "B"
        elseif dsl.noise_margin_down >= 7 and dsl.noise_margin_up >= 7 then
        	dsl.noise_margin_rate = "C"
        else
        	dsl.noise_margin_rate = "F"
        end

        if dsl.line_attenuation_down < 20 and dsl.line_attenuation_up < 20 then
        	dsl.line_attenuation_rate = "A+"
        elseif dsl.line_attenuation_down < 30 and dsl.line_attenuation_up < 30 then
        	dsl.line_attenuation_rate = "A"
        elseif dsl.line_attenuation_down < 40 and dsl.line_attenuation_up < 40 then
        	dsl.line_attenuation_rate = "B"
        elseif dsl.line_attenuation_down < 50 and dsl.line_attenuation_up < 50 then
        	dsl.line_attenuation_rate = "C"
        elseif dsl.line_attenuation_down < 60 and dsl.line_attenuation_up < 60 then
        	dsl.line_attenuation_rate = "D"
        else
        	dsl.line_attenuation_rate = "F"
	end

	return dsl
end

function get_modem_stats_variance()
	local dsl = get_dsl_stats()
	local dsl_last = get_dsl_stats("last")
	if dsl and dsl_last then
        	if math.abs((dsl_last.data_rate_down_s - dsl.data_rate_down_s)/dsl_last.data_rate_down_s * 100) > 20 then return true end
        	if math.abs((dsl_last.data_rate_up_s - dsl.data_rate_up_s)/dsl_last.data_rate_up_s * 100) > 20 then return true end
        	if math.abs((dsl_last.noise_margin_down - dsl.noise_margin_down)/dsl_last.noise_margin_down * 100) > 20 then return true end
        	if math.abs((dsl_last.noise_margin_up - dsl.noise_margin_up)/dsl_last.noise_margin_up * 100) > 20 then return true end
        	if math.abs((dsl_last.line_attenuation_down - dsl.line_attenuation_down)/dsl_last.line_attenuation_down * 100) > 20 then return true end
        	if math.abs((dsl_last.line_attenuation_up - dsl.line_attenuation_up)/dsl_last.line_attenuation_up * 100) > 20 then return true end
	end
	return false
end

function guess_type(type)
	local dsl
	if type ~= "vdsl" and type ~= "cable" and type ~= "dsl" then
		type = execw("cat /root/conn_type")
	else
		execute("echo '" .. type .. "' > /root/conn_type")
	end
	if type ~= "vdsl" and type ~= "cable" then
        	dsl = get_dsl_stats("last")
		if dsl then
			dsl.data_rate_up_s = dsl.data_rate_up_s or 0
        		dsl.data_rate_down_s = dsl.data_rate_down_s or 0
			type = "dsl"
		else
			type = "vdsl"
		end
        	if type == "vdsl" and execw("uci get network.Modem.ipaddr") == "192.168.100.2" then
            		type = "cable"
        	end
   	end
	return type, dsl
end

function get_user_matics(id, email)
    local type, dsl = guess_type("dsl")
    local lu = 0
    local ld = 0
    local snr = 0
    local atten = 0
    local qosup = execw("grep qosupload /root/iqtest.output.after | cut -f2 -d':'")
    local qosdown = execw("grep qosdownload /root/iqtest.output.after | cut -f2 -d':'")
    local isp = "tds"
    email = email or ""

    if dsl then
	lu = dsl.data_rate_up_s or 0
	ld = dsl.data_rate_down_s or 0
        snr = dsl.noise_margin_down or 0
        atten = dsl.line_attenuation_down or 0
    end

    return	[[conn=]]     .. type ..
		[[&lu=]]      .. lu ..
		[[&ld=]]      .. ld ..
		[[&snr=]]     .. snr ..
		[[&atten=]]   .. atten ..
		[[&qosup=]]   .. qosup ..
		[[&qosdown=]] .. qosdown ..
		[[&isp=]]     .. isp ..
		[[&email=]]   .. email ..
		[[&id=]]      .. id
end

function test_ping(gwip)
	return
		(execw("ping -c 1 -W 5 " .. gwip .. " 2>&1 | grep ' 0% packet loss'") ~= "") or
		(execw("ping -c 1 -W 5 " .. gwip .. " 2>&1 | grep ' 0% packet loss'") ~= "") or
		(execw("ping -c 1 -W 5 " .. gwip .. " 2>&1 | grep ' 0% packet loss'") ~= "")
end

function test_web_conn(web)
	return execute("curl -m 10 --silent -o /dev/null " .. web) == 0
end

function test_inet()
	return
		test_web_conn("google.com") or
		test_web_conn("evenroute.com") or
                test_web_conn("cnn.com")
end

function test_conn(gwip)
    if test_ping(gwip) then
                if test_inet() then
                        return "passed"
                else
                        return "no internet"
                end
        else
                return "unreachable"
        end
end


local cmd = [[SSL_CERT_DIR=/etc/ssl/certs curl -m 30 --silent]]
local url = [[https://evenroute.net/iq/]]

function register_firmware(email)
	local mac = execw("ifconfig eth0.2 | head -n 1 | awk '{print $5}'")
	local unp = [[ -d "username=EvenRouteAPI&password=FastRouterAPI"]]
	local srv = [[ "]] .. url .. [[register_firmware.php?reg=]] .. mac .. [["]]
	local str = exec(cmd .. unp .. srv)
	local usr, psw, ncs = string.match(str, "username=(%w+)|password=(%w+)|newcustomer=(%w+)")
	if usr and psw and ncs then
		local u_p = "username=" .. usr .. "&password=" .. psw
		local umt = get_user_matics(mac, email)
		local rts = "\nregister_time=" .. os.time() .. "\n"
		writefile("/root/evenroute_register", u_p .. "\n" .. umt .. rts)
		return usr, psw, umt
	else
		return str
	end
end

function get_usr_psw()
        local usr_psw = execw("grep '^username=.*&password=.*$' /root/evenroute_register")
        if usr_psw == "" then
                local usr, psw = register_firmware()
                if usr and psw then                 
                        usr_psw = "username=" .. usr .. "&password=" .. psw            
                end                                                               
        end                                                                               
        return usr_psw                                                   
end
                 
function upload_ui_log(file)
	local usr, psw = get_usr_psw():match("username=(%w+)&password=(%w+)")
	if usr and psw and fs.access(file) then
		local unp = [[ -u "]] .. usr .. [[:]] .. psw .. [["]]
		local uif = [[ -F "userfile=@"]] .. file
		local srv = [[ -L "]] .. url .. [[upload_ui_log.php"]]
        	return exec(cmd .. unp .. uif .. srv)
	end
end

function create_config_backup()
        exec([[
                cp -r /etc /root/etc;
                sed -i -r 's/[^:]+/*/2' /root/etc/shadow /root/etc/passwd;
                sed -i "s/option key.*/option key ''/" /root/etc/config/wireless;
                tar -czvf /root/etc.tar.gz /root/etc;
                rm -rf /root/etc;
        ]])
	exec[[sh /etc/init.d/iqrouter_upload_configuration.service "/root/etc.tar.gz" &]]
end

function user_metrics(email, bg)
	local usr_psw = get_usr_psw()
	local umt = execl("grep 'conn=' /root/evenroute_register | sed 's/email=[^&]*/email=" .. email .. "/'")
        if usr_psw and umt ~= "" then
                local unp = [[ -d "]] .. usr_psw .. [["]]
                local srv = [[ "]] .. url .. [[user_metrics.php?]] .. umt .. [["]]
                local rts = "\nregister_time=" .. os.time() .. "\n"
                writefile("/root/evenroute_register", usr_psw .. "\n" .. umt .. rts)
		if bg == "1" then
                	exec(cmd .. unp .. srv .. " &")
			return "ok"
		else
                	return exec(cmd .. unp .. srv)
		end
	end
end

function check_upgrade(usr_psw, type, ver)
	if ver == "" then ver = "0.0.0" end
	usr_psw = usr_psw or get_usr_psw()
	local unp = [[ -d "]] .. usr_psw .. [["]]
        local srv = [[ "]] .. url .. [[upgrade.php?]] .. type .. [[=]].. ver .. [["]]
        return exec(cmd .. unp .. srv) or ""
end

function check_firmware_upgrade(usr_psw)
	local ver = execw("egrep '^[0-9]+\\.[0-9]+\\.[0-9]+$' /etc/iqr_version")
	return check_upgrade(usr_psw, "firmware", ver)
end

function check_iqtest_upgrade(usr_psw)
	local ver = execw("sh /root/iqtest.sh -v | egrep -o '[0-9]+\\.[0-9]+\\.[0-9]+'")
	return check_upgrade(usr_psw, "iqtest", ver)
end

function check_all_upgrade()
	local usr_psw = get_usr_psw()
	local upgrade_firmware = ""
	if usr_psw ~= "" then
		upgrade_firmware = check_firmware_upgrade(usr_psw)
		execute("sed -i '4,$d' /root/evenroute_register")
                execute("echo 'upgrade_time=" .. os.time() .. "' >> /root/evenroute_register")
                execute("echo 'upgrade_firmware=" .. upgrade_firmware .. "' >> /root/evenroute_register")
	end
	return upgrade_firmware
end

function get_reg_email()
	local email = exec("grep -o 'email=.*&' /root/evenroute_register")
        if email then
       		email = string.match(email, "email=(.*)&")
        end
	return email or ""
end

function download_file(url, dst)
	if execute(cmd .. " -k -o " .. dst .. " " .. url) == 0 then
		execute("sed -i 's/=" .. string.gsub(url, "/", "\\/") .. "$/=/' /root/evenroute_register")
		return true
	else
		return false
	end
end

function get_upgrade_log()
	local upgrade_time = tonumber(execw("grep upgrade_time /root/evenroute_register | cut -f2 -d'='")) or 0
	local upgrade_firmware =  execw("grep upgrade_firmware /root/evenroute_register | cut -f2 -d'='")
        local has_inet_conn = test_web_conn("google.com")
        if (os.time() - upgrade_time) > 86400 and has_inet_conn then
        	upgrade_firmware = check_all_upgrade()
        end
	return has_inet_conn, upgrade_firmware
end

function upgrade_iqtest(url)
	if download_file(url or check_iqtest_upgrade(), "/root/iqtest") then
		execute([[[ "$(grep -o PAXYM_TESTED /root/iqtest.sh)" == "PAXYM_TESTED" ] && mv /root/iqtest /root/iqtest.sh]])
		return true
	end
end

function download_firmware(url)
	local image_tmp = "/tmp/firmware.img"
	if download_file(url, image_tmp) then
		return ( 0 == os.execute(                                                                                           
        		". /lib/functions.sh; " ..                                                                                                
        		"include /lib/upgrade; " ..                                                     
        		"platform_check_image %q >/dev/null"                                                            
        		% image_tmp
		))
	end
end
